from django.apps import AppConfig


class JiagouappConfig(AppConfig):
    name = 'JiaGouapp'
